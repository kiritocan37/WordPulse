# WordPulse

Dark editorial news aggregator. Pulls headlines from 8 international RSS sources, auto-categorizes them (world / politics / tech / culture), and translates titles and descriptions into **English, Russian, or Ukrainian** on the fly.

**Live:** deployed on Vercel · **Stack:** Node.js + Express (serverless), vanilla JS frontend

## Sources

BBC World (UK) · The New York Times (US) · Al Jazeera (QA) · Deutsche Welle (DE) · Le Monde (FR) · Українська правда (UA) · Polsat News (PL) · RBC (RU)

## Features

- 🌍 8 feeds fetched in parallel with per-feed timeouts, fallback URLs, and `Promise.allSettled` resilience — one dead feed never breaks the page
- 🈯 On-the-fly translation (google-translate-api-x with LibreTranslate fallback), with a 1-hour translation cache
- 🗂 Multilingual keyword categorization (EN/FR/DE/RU/UK/PL)
- 🖼 Article images extracted from enclosure / media:content / media:thumbnail / inline HTML
- ⚡ Edge caching: `/api/articles` responses are cached on Vercel's CDN (`s-maxage=600, stale-while-revalidate=1800`) per language/filter combination
- 📄 Pagination with "Load more", source-diversity cap (max 8 articles per source)
- 🌐 Fully localized UI (EN/RU/UA) with persisted language preference
- 🛡 Safe DOM construction (no innerHTML for feed content), URL validation, `rel="noopener noreferrer"`

## Architecture

```
api/index.js      → Vercel serverless entry (wraps the Express app)
server.js         → local dev entry (node server.js)
src/app.js        → Express app (shared by both)
src/routes.js     → /api/articles, /api/sources
src/feeds.js      → feed config, fetching, categorization, image extraction
src/translate.js  → translation with fallback + caching
src/cache.js      → TTL cache with stampede protection
public/           → static frontend (served by Vercel CDN in production)
```

## Run locally

```bash
npm install
npm start          # http://localhost:3000
```

## API

```
GET /api/articles?lang=en|ru|ua&category=&country=&offset=0&limit=18
GET /api/sources
```

Response: `{ articles, total, offset, limit, hasMore }`
