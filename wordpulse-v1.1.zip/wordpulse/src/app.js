'use strict';

const express = require('express');
const cors = require('cors');
const path = require('path');
const apiRoutes = require('./routes');

const app = express();

app.use(cors());
app.use(express.json());

// API Routes
app.use('/api', apiRoutes);

// Static + SPA fallback (used in local dev; on Vercel public/ is served by the CDN)
app.use(express.static(path.join(__dirname, '..', 'public')));
app.get(/(.*)/, (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

module.exports = app;
