'use strict';

const express = require('express');
const router = express.Router();
const { fetchAllFeeds, FEED_SOURCES } = require('./feeds');
const { Cache } = require('./cache');
const { translateArticle } = require('./translate');

// In-memory cache for RSS feeds (10 minutes TTL).
// Note: on serverless this only helps warm instances — the real caching
// layer is the CDN via the Cache-Control header below.
const articleCache = new Cache(10 * 60 * 1000);
const CACHE_KEY = 'all_articles';

const PAGE_SIZE = 18;
const MAX_LIMIT = 30;
const MAX_PER_SOURCE = 8;

/**
 * Fetch articles, either from cache or directly from RSS.
 */
async function getArticles() {
  return articleCache.getOrFetch(CACHE_KEY, () => fetchAllFeeds());
}

// GET /api/articles?lang=&country=&category=&offset=&limit=
router.get('/articles', async (req, res) => {
  try {
    const country = req.query.country || '';
    const category = req.query.category || '';
    const lang = req.query.lang || 'en';
    const offset = Math.max(0, parseInt(req.query.offset, 10) || 0);
    const limit = Math.min(MAX_LIMIT, Math.max(1, parseInt(req.query.limit, 10) || PAGE_SIZE));

    let articles = await getArticles();

    // Filter by country
    if (country) {
      articles = articles.filter(a => a.country.toLowerCase() === country.toLowerCase());
    }

    // Filter by category
    if (category) {
      articles = articles.filter(a => a.category.toLowerCase() === category.toLowerCase());
    }

    // Source diversity: cap articles per source so one feed can't dominate
    const articlesBySource = {};
    for (const a of articles) {
      if (!articlesBySource[a.sourceId]) {
        articlesBySource[a.sourceId] = [];
      }
      if (articlesBySource[a.sourceId].length < MAX_PER_SOURCE) {
        articlesBySource[a.sourceId].push(a);
      }
    }

    const diverseArticles = Object.values(articlesBySource).flat();
    diverseArticles.sort((a, b) => new Date(b.pubDate) - new Date(a.pubDate));

    const total = diverseArticles.length;
    const paginated = diverseArticles.slice(offset, offset + limit);

    const translatedArticles = [];
    const CONCURRENCY_LIMIT = 5;

    for (let i = 0; i < paginated.length; i += CONCURRENCY_LIMIT) {
      const chunk = paginated.slice(i, i + CONCURRENCY_LIMIT);
      const promises = chunk.map(a => translateArticle(a, lang));
      const results = await Promise.allSettled(promises);

      results.forEach((result, index) => {
        if (result.status === 'fulfilled') {
          translatedArticles.push(result.value);
        } else {
          console.error('Translation error:', result.reason);
          translatedArticles.push(chunk[index]); // Graceful fallback
        }
      });
    }

    // Edge/CDN caching: each unique (lang, category, country, offset) combo
    // is cached at Vercel's edge for 10 min and served stale for up to 30 min
    // while revalidating in the background. This is the main performance layer.
    res.set('Cache-Control', 'public, s-maxage=600, stale-while-revalidate=1800');

    res.json({
      articles: translatedArticles,
      total,
      offset,
      limit,
      hasMore: offset + paginated.length < total
    });
  } catch (err) {
    console.error('Error fetching articles:', err);
    res.status(500).json({ error: 'Failed to fetch articles' });
  }
});

// GET /api/sources
router.get('/sources', (req, res) => {
  res.set('Cache-Control', 'public, s-maxage=3600, stale-while-revalidate=86400');
  res.json(FEED_SOURCES.map(s => ({
    id: s.id,
    name: s.name,
    country: s.country,
    language: s.language
  })));
});

module.exports = router;
