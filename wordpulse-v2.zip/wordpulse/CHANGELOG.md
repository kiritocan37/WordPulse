# Changelog

## [2.0.0] — 2026-06-10

### Architecture
- Storage abstraction (`src/store.js`): Upstash Redis when configured, in-memory fallback otherwise
- Pre-translated language editions built by `src/refresh.js`; `/api/articles` is now a pure read
- `/api/refresh` cron endpoint (Vercel Cron, daily) with `CRON_SECRET` protection
- DeepL API as primary translation provider, Google (unofficial) and LibreTranslate as fallbacks
- Persistent 7-day translation cache — only new articles cost translation calls
- Rate limiting (60 req/min per IP) when Redis is configured
- `/api/health` endpoint for uptime monitoring
- Query parameter validation (400 on invalid lang/category/country)
- Structured JSON logging via pino

### Frontend
- Image proxy (weserv.nl): article images resized + converted to WebP
- Skeleton loaders replacing the text loader
- Bookmarks: save articles to localStorage, "Saved" view
- PWA: manifest, icons, service worker with offline support
- Self-hosted fonts (latin + latin-ext + cyrillic subsets), no Google Fonts requests
- Visible keyboard focus styles, `prefers-reduced-motion` support

### Tooling
- Offline test suite (27 tests): node:test + nock fixtures + supertest
- ESLint (flat config) + Prettier
- Type checking via `tsc --noEmit` with `checkJs` (JSDoc-driven)
- GitHub Actions CI: lint + typecheck + tests on every push/PR

## [1.1.0] — 2026-06-10

- Serverless restructure (api/index.js entry, CDN-served static files)
- Edge caching via Cache-Control s-maxage on API responses
- Pagination with Load more; per-source diversity cap
- New sources: NYT (replacing dead Reuters PR feed), Українська правда, Polsat News
- Article images rendered (hero banner + card covers)
- Full UI localization (EN/RU/UA), persisted language preference
- Relative timestamps, word-boundary truncation
- Meta/OG tags, favicon, unified WordPulse naming

## [1.0.0]

- Initial release
