# Suggested commit sequence

Don't upload everything as one "Add files via upload". Clone the repo locally,
copy these files in, and commit in logical chunks — this is what makes the
history look like real engineering work:

```bash
git clone https://github.com/kiritocan37/WordPulse.git && cd WordPulse
# copy the new files over, then:

git add src/store.js src/logger.js src/translate.js src/refresh.js src/routes.js src/app.js api/ server.js vercel.json package.json package-lock.json
git commit -m "feat: serverless architecture — Redis store, pre-translated editions, cron refresh, DeepL chain, rate limiting"

git add test/ 
git commit -m "test: offline suite with nock fixtures and supertest (27 tests)"

git add eslint.config.js .prettierrc jsconfig.json .github/
git commit -m "chore: ESLint, Prettier, JSDoc type checking, GitHub Actions CI"

git add public/
git commit -m "feat(ui): PWA, image proxy, skeletons, bookmarks, self-hosted fonts, a11y"

git add README.md CHANGELOG.md .env.example COMMIT_PLAN.md src/feeds.js
git commit -m "docs: README v2, changelog, env template"

git push
```

Delete this file after using it.
