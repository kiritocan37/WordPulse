# WordPulse

[![CI](https://github.com/kiritocan37/WordPulse/actions/workflows/ci.yml/badge.svg)](https://github.com/kiritocan37/WordPulse/actions/workflows/ci.yml)

Dark editorial news aggregator. Pulls headlines from 8 international RSS sources, auto-categorizes them (world / politics / tech / culture), and serves them pre-translated into **English, Russian, or Ukrainian**.

**Stack:** Node.js + Express (Vercel serverless) · Upstash Redis · vanilla JS PWA frontend

## Sources

BBC World (UK) · The New York Times (US) · Al Jazeera (QA) · Deutsche Welle (DE) · Le Monde (FR) · Українська правда (UA) · Polsat News (PL) · RBC (RU)

## How it works

```
                    ┌─ Vercel Cron (daily) ──► /api/refresh
                    │       fetch 8 feeds in parallel
                    │       categorize + extract images
                    │       translate NEW articles (DeepL → Google → Libre)
                    │       write editions to Redis (en / ru / ua)
                    ▼
   Upstash Redis ◄──┴──► /api/articles  (pure read + filter + paginate)
                              │
                              ▼
                    Vercel Edge CDN (s-maxage=600, SWR=1800)
                              │
                              ▼
                          Browser (PWA, offline-capable)
```

Nothing slow happens on the request path: articles are pre-translated by the refresh job, individual translations are cached for 7 days (only genuinely new articles cost API calls), responses are cached at the CDN edge per language/filter combination, and the service worker keeps the last response available offline.

**Graceful degradation:** without Redis/DeepL keys the app still works — in-memory caching, unofficial translation providers, on-demand refresh. Adding the keys upgrades it, never gates it.

## Features

- 8 feeds fetched in parallel with per-feed timeouts, fallback URLs, and `Promise.allSettled` resilience
- Translation provider chain: DeepL (official) → Google → LibreTranslate, with persistent caching
- Multilingual keyword categorization (EN/FR/DE/RU/UK/PL)
- Article images via [weserv](https://images.weserv.nl) proxy: resized, WebP, CDN-cached
- Fully localized UI (EN/RU/UA), persisted language preference, relative timestamps
- Bookmarks ("Saved" view, localStorage), skeleton loaders
- PWA: installable, offline support via service worker
- Self-hosted fonts (latin + cyrillic subsets) — zero third-party font requests
- Rate limiting (60 req/min/IP), query validation, structured logging, `/api/health`
- Accessibility: keyboard focus styles, `prefers-reduced-motion`, ARIA labels

## Project structure

```
api/index.js      → Vercel serverless entry
server.js         → local dev entry (node server.js)
src/app.js        → Express app + rate limiting
src/routes.js     → /api/articles, /api/sources, /api/health, /api/refresh
src/refresh.js    → edition builder (fetch → categorize → translate → store)
src/feeds.js      → feed config, parsing, categorization, image extraction
src/translate.js  → DeepL/Google/Libre chain + persistent cache
src/store.js      → Upstash Redis with in-memory fallback
src/cache.js      → TTL cache with stampede protection
src/logger.js     → pino structured logging
public/           → static PWA frontend (served by Vercel CDN)
test/             → offline test suite (node:test + nock + supertest)
```

## Setup

```bash
npm install
cp .env.example .env   # fill in keys (all optional — see comments)
npm start              # http://localhost:3000
```

### Production env vars (Vercel → Settings → Environment Variables)

| Variable | Required | Purpose |
|---|---|---|
| `UPSTASH_REDIS_REST_URL` / `_TOKEN` | recommended | persistent cache + rate limiting |
| `DEEPL_API_KEY` | recommended | reliable translation (500k chars/mo free) |
| `CRON_SECRET` | recommended | protects /api/refresh |
| `TELEGRAM_BOT_TOKEN` / `TELEGRAM_CHAT_ID` | optional | daily digest to a Telegram channel |

## Scripts

```bash
npm test               # offline test suite (27 tests)
npm run test:coverage  # with c8 coverage report
npm run lint           # ESLint
npm run typecheck      # tsc --noEmit (JSDoc-driven type checking)
```

## API

```
GET /api/articles?lang=en|ru|ua&category=&country=&offset=0&limit=18
GET /api/sources
GET /api/health
GET /api/refresh        (Authorization: Bearer <CRON_SECRET>)
```

Articles response: `{ articles, total, offset, limit, hasMore, updatedAt }`
