'use strict';

// Vercel serverless entry point. Static assets in /public are served
// directly by Vercel's CDN; only /api/* requests reach this function.
module.exports = require('../src/app');
