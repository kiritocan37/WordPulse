'use strict';

const nodeGlobals = {
  require: 'readonly', module: 'writable', process: 'readonly',
  __dirname: 'readonly', console: 'readonly', setTimeout: 'readonly',
  clearTimeout: 'readonly', setInterval: 'readonly', clearInterval: 'readonly',
  Buffer: 'readonly', fetch: 'readonly', AbortController: 'readonly',
  URL: 'readonly', Promise: 'readonly'
};

const browserGlobals = {
  window: 'readonly', document: 'readonly', localStorage: 'readonly',
  fetch: 'readonly', URL: 'readonly', AbortController: 'readonly',
  IntersectionObserver: 'readonly', navigator: 'readonly',
  setTimeout: 'readonly', clearTimeout: 'readonly', console: 'readonly',
  caches: 'readonly', self: 'readonly', Response: 'readonly'
};

module.exports = [
  {
    ignores: ['node_modules/**', 'coverage/**', 'public/fonts/**']
  },
  {
    files: ['src/**/*.js', 'api/**/*.js', 'test/**/*.js', 'server.js'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'commonjs',
      globals: nodeGlobals
    },
    rules: {
      'no-unused-vars': ['error', { argsIgnorePattern: '^_|^req$|^res$|^next$' }],
      'no-undef': 'error',
      'eqeqeq': ['error', 'smart'],
      'no-var': 'error',
      'prefer-const': 'error'
    }
  },
  {
    files: ['public/js/**/*.js', 'public/sw.js'],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: 'script',
      globals: browserGlobals
    },
    rules: {
      'no-unused-vars': 'error',
      'no-undef': 'error',
      'eqeqeq': ['error', 'smart'],
      'no-var': 'error',
      'prefer-const': 'error'
    }
  }
];
