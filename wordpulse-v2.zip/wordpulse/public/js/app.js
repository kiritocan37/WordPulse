document.addEventListener('DOMContentLoaded', () => {
  const loader = document.getElementById('loader');
  const errorMessage = document.getElementById('error-message');
  const heroSection = document.getElementById('hero-section');
  const bentoGrid = document.getElementById('bento-grid');
  const sectionDivider = document.getElementById('section-divider');
  const langSelect = document.getElementById('lang-select');
  const editionDate = document.getElementById('edition-date');
  const loadMoreWrap = document.getElementById('load-more-wrap');
  const loadMoreBtn = document.getElementById('load-more');
  const savedViewBtn = document.getElementById('saved-view-btn');
  const catFilters = document.querySelectorAll('#category-filters .filter-btn[data-category]');
  const countryFilters = document.querySelectorAll('#country-filters .filter-btn');

  const PAGE_SIZE = 18;
  const BOOKMARKS_KEY = 'wordpulse_saved';

  // ---------- i18n ----------
  const I18N = {
    en: {
      allCategories: 'All Categories', world: 'World', politics: 'Politics',
      tech: 'Tech', culture: 'Culture', saved: 'Saved',
      allRegions: 'All Regions', uk: 'UK', us: 'US', qa: 'Qatar', de: 'Germany',
      fr: 'France', ua: 'Ukraine', pl: 'Poland', ru: 'Russia',
      loading: 'Loading latest global pulse…',
      loadMore: 'Load more', loadingMore: 'Loading…',
      noArticles: 'No articles found matching the selected criteria.',
      savedEmpty: 'No saved articles yet. Tap ☆ on any article to save it for later.',
      offline: 'You are offline — showing the last loaded articles.',
      timeout: 'Request timed out. Please check your connection and try again.',
      fetchFailed: 'Failed to fetch articles',
      footerTag: 'Editorial Global Aggregator',
      saveLabel: 'Save article', unsaveLabel: 'Remove from saved',
      justNow: 'just now', minAgo: 'm ago', hourAgo: 'h ago', dayAgo: 'd ago',
      locale: 'en-US'
    },
    ru: {
      allCategories: 'Все категории', world: 'Мир', politics: 'Политика',
      tech: 'Технологии', culture: 'Культура', saved: 'Сохранённые',
      allRegions: 'Все регионы', uk: 'Великобритания', us: 'США', qa: 'Катар',
      de: 'Германия', fr: 'Франция', ua: 'Украина', pl: 'Польша', ru: 'Россия',
      loading: 'Загружаем мировой пульс…',
      loadMore: 'Показать ещё', loadingMore: 'Загрузка…',
      noArticles: 'Нет статей по выбранным фильтрам.',
      savedEmpty: 'Пока нет сохранённых статей. Нажмите ☆ на любой статье.',
      offline: 'Вы офлайн — показаны последние загруженные статьи.',
      timeout: 'Время запроса истекло. Проверьте соединение и попробуйте снова.',
      fetchFailed: 'Не удалось загрузить статьи',
      footerTag: 'Глобальный новостной агрегатор',
      saveLabel: 'Сохранить статью', unsaveLabel: 'Убрать из сохранённых',
      justNow: 'только что', minAgo: ' мин назад', hourAgo: ' ч назад', dayAgo: ' дн назад',
      locale: 'ru-RU'
    },
    ua: {
      allCategories: 'Всі категорії', world: 'Світ', politics: 'Політика',
      tech: 'Технології', culture: 'Культура', saved: 'Збережені',
      allRegions: 'Всі регіони', uk: 'Велика Британія', us: 'США', qa: 'Катар',
      de: 'Німеччина', fr: 'Франція', ua: 'Україна', pl: 'Польща', ru: 'Росія',
      loading: 'Завантажуємо світовий пульс…',
      loadMore: 'Показати ще', loadingMore: 'Завантаження…',
      noArticles: 'Немає статей за обраними фільтрами.',
      savedEmpty: 'Поки немає збережених статей. Натисніть ☆ на будь-якій статті.',
      offline: 'Ви офлайн — показано останні завантажені статті.',
      timeout: 'Час запиту минув. Перевірте з\u2019єднання та спробуйте ще раз.',
      fetchFailed: 'Не вдалося завантажити статті',
      footerTag: 'Глобальний новинний агрегатор',
      saveLabel: 'Зберегти статтю', unsaveLabel: 'Прибрати зі збережених',
      justNow: 'щойно', minAgo: ' хв тому', hourAgo: ' год тому', dayAgo: ' дн тому',
      locale: 'uk-UA'
    }
  };

  function t(key) {
    const dict = I18N[currentLang] || I18N.en;
    return dict[key] !== undefined ? dict[key] : (I18N.en[key] || key);
  }

  function applyTranslations() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
      el.textContent = t(el.dataset.i18n);
    });
    document.documentElement.lang = currentLang === 'ua' ? 'uk' : currentLang;
    if (editionDate) {
      editionDate.textContent = new Date().toLocaleDateString(t('locale'), {
        weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
      });
    }
  }

  // ---------- State ----------
  const savedLang = localStorage.getItem('wordpulse_lang');
  if (savedLang && I18N[savedLang]) {
    langSelect.value = savedLang;
  }
  let currentLang = langSelect.value || 'en';
  let currentCategory = '';
  let currentCountry = '';
  let currentOffset = 0;
  let savedView = false;
  let currentAbortController = null;

  // ---------- Bookmarks ----------
  function getBookmarks() {
    try {
      return JSON.parse(localStorage.getItem(BOOKMARKS_KEY)) || [];
    } catch {
      return [];
    }
  }

  function isBookmarked(article) {
    return getBookmarks().some(b => b.link === article.link);
  }

  function toggleBookmark(article) {
    let list = getBookmarks();
    if (list.some(b => b.link === article.link)) {
      list = list.filter(b => b.link !== article.link);
    } else {
      list.unshift(article);
      list = list.slice(0, 100); // sane cap
    }
    localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(list));
    return list.some(b => b.link === article.link);
  }

  // ---------- Helpers ----------
  function isSafeUrl(url) {
    try {
      const parsedUrl = new URL(url, window.location.origin);
      return parsedUrl.protocol === 'http:' || parsedUrl.protocol === 'https:';
    } catch {
      return false;
    }
  }

  /**
   * Route article images through the weserv proxy: resized, converted to
   * WebP, and cached on their CDN. Raw RSS images are often 500KB+ JPEGs.
   */
  function proxyImage(url, width) {
    const stripped = url.replace(/^https?:\/\//, '');
    return 'https://images.weserv.nl/?url=' + encodeURIComponent(stripped) +
      '&w=' + width + '&output=webp&q=72&fit=cover';
  }

  function truncateAtWord(text, maxLen) {
    if (!text || text.length <= maxLen) return text || '';
    const cut = text.substring(0, maxLen);
    const lastSpace = cut.lastIndexOf(' ');
    return (lastSpace > maxLen * 0.6 ? cut.substring(0, lastSpace) : cut) + '…';
  }

  function relativeTime(dateStr) {
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return '';
    const mins = Math.floor((Date.now() - date.getTime()) / 60000);
    if (mins < 1) return t('justNow');
    if (mins < 60) return mins + t('minAgo');
    const hours = Math.floor(mins / 60);
    if (hours < 24) return hours + t('hourAgo');
    const days = Math.floor(hours / 24);
    if (days < 7) return days + t('dayAgo');
    return date.toLocaleDateString(t('locale'));
  }

  function createArticleImage(article, className, width) {
    if (!article.imageUrl || !isSafeUrl(article.imageUrl)) return null;
    const img = document.createElement('img');
    img.className = className;
    img.src = proxyImage(article.imageUrl, width);
    img.alt = '';
    img.loading = 'lazy';
    img.decoding = 'async';
    img.referrerPolicy = 'no-referrer';
    img.addEventListener('error', () => img.remove());
    return img;
  }

  function createSaveButton(article) {
    const btn = document.createElement('button');
    btn.className = 'save-btn';
    btn.type = 'button';
    const update = (saved) => {
      btn.textContent = saved ? '★' : '☆';
      btn.classList.toggle('saved', saved);
      btn.setAttribute('aria-label', saved ? t('unsaveLabel') : t('saveLabel'));
      btn.setAttribute('aria-pressed', String(saved));
    };
    update(isBookmarked(article));
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const saved = toggleBookmark(article);
      update(saved);
      if (savedView && !saved) {
        renderSavedView();
      }
    });
    return btn;
  }

  // ---------- Init ----------
  applyTranslations();
  fetchArticles(true);

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  }

  // ---------- Event Listeners ----------
  langSelect.addEventListener('change', (e) => {
    currentLang = e.target.value;
    localStorage.setItem('wordpulse_lang', currentLang);
    applyTranslations();
    if (savedView) {
      renderSavedView();
    } else {
      fetchArticles(true);
    }
  });

  catFilters.forEach(btn => {
    btn.addEventListener('click', (e) => {
      exitSavedView();
      catFilters.forEach(b => b.classList.remove('active'));
      e.currentTarget.classList.add('active');
      currentCategory = e.currentTarget.dataset.category;
      fetchArticles(true);
    });
  });

  countryFilters.forEach(btn => {
    btn.addEventListener('click', (e) => {
      exitSavedView();
      countryFilters.forEach(b => b.classList.remove('active'));
      e.currentTarget.classList.add('active');
      currentCountry = e.currentTarget.dataset.country;
      fetchArticles(true);
    });
  });

  savedViewBtn.addEventListener('click', () => {
    savedView = true;
    catFilters.forEach(b => b.classList.remove('active'));
    savedViewBtn.classList.add('active');
    savedViewBtn.setAttribute('aria-pressed', 'true');
    renderSavedView();
  });

  function exitSavedView() {
    savedView = false;
    savedViewBtn.classList.remove('active');
    savedViewBtn.setAttribute('aria-pressed', 'false');
  }

  loadMoreBtn.addEventListener('click', () => fetchArticles(false));

  // ---------- Data fetching ----------
  async function fetchArticles(reset) {
    if (reset) {
      currentOffset = 0;
      showSkeletons();
    } else {
      loadMoreBtn.disabled = true;
      loadMoreBtn.textContent = t('loadingMore');
    }

    if (currentAbortController) {
      currentAbortController.abort();
    }
    const controller = new AbortController();
    currentAbortController = controller;

    try {
      const url = new URL('/api/articles', window.location.origin);
      url.searchParams.append('lang', currentLang);
      url.searchParams.append('offset', String(currentOffset));
      url.searchParams.append('limit', String(PAGE_SIZE));
      if (currentCategory) url.searchParams.append('category', currentCategory);
      if (currentCountry) url.searchParams.append('country', currentCountry);

      const FETCH_TIMEOUT = 30000;
      const timeoutId = setTimeout(() => controller.abort('timeout'), FETCH_TIMEOUT);

      const response = await fetch(url, { signal: controller.signal });
      clearTimeout(timeoutId);
      if (!response.ok) throw new Error(t('fetchFailed'));

      const data = await response.json();
      const articles = Array.isArray(data) ? data : (data.articles || []);
      const hasMore = Array.isArray(data) ? false : !!data.hasMore;

      if (data.offline) {
        showNotice(t('offline'));
      }

      renderArticles(articles, { append: !reset, hasMore });
      currentOffset += articles.length;
    } catch (err) {
      if (err.name === 'AbortError') {
        if (controller === currentAbortController && controller.signal.reason === 'timeout') {
          showError(t('timeout'));
        }
        return;
      }
      showError(err.message);
    } finally {
      loadMoreBtn.disabled = false;
      loadMoreBtn.textContent = t('loadMore');
    }
  }

  // ---------- Rendering ----------
  const revealObserver = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  function buildCard(article, index) {
    const card = document.createElement('article');
    card.className = 'card reveal';
    card.style.transitionDelay = Math.min(index * 0.06, 0.6) + 's';

    const img = createArticleImage(article, 'card-img', 640);
    if (img) card.appendChild(img);

    const body = document.createElement('div');
    body.className = 'card-body';

    const cardMeta = document.createElement('div');
    cardMeta.className = 'card-meta';
    const cardSource = document.createElement('span');
    cardSource.textContent = `${article.source} (${article.country})`;
    const cardRight = document.createElement('span');
    const catLabel = t(article.category) !== article.category ? t(article.category) : article.category;
    cardRight.textContent = `${catLabel} · ${relativeTime(article.pubDate)}`;
    cardMeta.append(cardSource, cardRight);

    const cardTitle = document.createElement('h2');
    cardTitle.className = 'card-title';
    const cardLink = document.createElement('a');
    cardLink.textContent = article.title;
    if (article.link && isSafeUrl(article.link)) {
      cardLink.href = article.link;
      cardLink.target = '_blank';
      cardLink.rel = 'noopener noreferrer';
    } else {
      cardLink.href = '#';
      cardLink.addEventListener('click', e => e.preventDefault());
    }
    cardTitle.appendChild(cardLink);

    const cardDesc = document.createElement('p');
    cardDesc.className = 'card-desc';
    cardDesc.textContent = truncateAtWord(article.description, 150);

    const cardFooter = document.createElement('div');
    cardFooter.className = 'card-footer';
    cardFooter.appendChild(createSaveButton(article));

    body.append(cardMeta, cardTitle, cardDesc, cardFooter);
    card.appendChild(body);
    return card;
  }

  function renderHero(article) {
    heroSection.innerHTML = '';

    const heroImg = createArticleImage(article, 'hero-img', 1280);
    if (heroImg) heroSection.appendChild(heroImg);

    const heroContent = document.createElement('div');
    heroContent.className = 'hero-content';

    const heroMeta = document.createElement('div');
    heroMeta.className = 'hero-meta';
    const heroSource = document.createElement('span');
    heroSource.textContent = article.source;
    const heroDate = document.createElement('span');
    heroDate.textContent = relativeTime(article.pubDate);
    const heroCategory = document.createElement('span');
    heroCategory.textContent = t(article.category) !== article.category ? t(article.category) : article.category;
    heroMeta.append(heroSource, heroDate, heroCategory);

    const heroTitle = document.createElement('h1');
    heroTitle.className = 'hero-title';
    const heroLink = document.createElement('a');
    heroLink.textContent = article.title;
    if (article.link && isSafeUrl(article.link)) {
      heroLink.href = article.link;
      heroLink.target = '_blank';
      heroLink.rel = 'noopener noreferrer';
    } else {
      heroLink.href = '#';
      heroLink.addEventListener('click', e => e.preventDefault());
    }
    heroTitle.appendChild(heroLink);

    const heroDesc = document.createElement('p');
    heroDesc.className = 'hero-desc';
    heroDesc.textContent = article.description || '';

    const heroFooter = document.createElement('div');
    heroFooter.className = 'card-footer';
    heroFooter.appendChild(createSaveButton(article));

    heroContent.append(heroMeta, heroTitle, heroDesc, heroFooter);
    heroSection.appendChild(heroContent);
    heroSection.classList.remove('hidden');
  }

  function renderArticles(articles, { append, hasMore }) {
    hideLoader();

    if (!append) {
      heroSection.innerHTML = '';
      bentoGrid.innerHTML = '';

      if (!articles || articles.length === 0) {
        showError(t('noArticles'));
        loadMoreWrap.classList.add('hidden');
        return;
      }

      renderHero(articles[0]);
      if (sectionDivider) sectionDivider.classList.remove('hidden');
      articles.slice(1).forEach((article, index) => {
        const card = buildCard(article, index);
        bentoGrid.appendChild(card);
        revealObserver.observe(card);
      });
    } else {
      articles.forEach((article, index) => {
        const card = buildCard(article, index);
        bentoGrid.appendChild(card);
        revealObserver.observe(card);
      });
    }

    bentoGrid.classList.remove('hidden');
    loadMoreWrap.classList.toggle('hidden', !hasMore || savedView);
  }

  function renderSavedView() {
    hideLoader();
    errorMessage.classList.add('hidden');
    heroSection.classList.add('hidden');
    heroSection.innerHTML = '';
    bentoGrid.innerHTML = '';
    loadMoreWrap.classList.add('hidden');
    if (sectionDivider) sectionDivider.classList.add('hidden');

    const saved = getBookmarks();
    if (saved.length === 0) {
      showNotice(t('savedEmpty'));
      return;
    }
    saved.forEach((article, index) => {
      const card = buildCard(article, index);
      bentoGrid.appendChild(card);
      revealObserver.observe(card);
    });
    bentoGrid.classList.remove('hidden');
  }

  // ---------- UI state helpers ----------
  function showSkeletons() {
    loader.classList.add('hidden');
    errorMessage.classList.add('hidden');
    loadMoreWrap.classList.add('hidden');
    if (sectionDivider) sectionDivider.classList.remove('hidden');

    heroSection.innerHTML = '';
    heroSection.classList.remove('hidden');
    const heroSkel = document.createElement('div');
    heroSkel.className = 'skeleton skeleton-hero';
    heroSection.appendChild(heroSkel);

    bentoGrid.innerHTML = '';
    bentoGrid.classList.remove('hidden');
    for (let i = 0; i < 6; i++) {
      const s = document.createElement('div');
      s.className = 'skeleton skeleton-card';
      bentoGrid.appendChild(s);
    }
  }

  function hideLoader() {
    loader.classList.add('hidden');
    errorMessage.classList.add('hidden');
  }

  function showNotice(msg) {
    errorMessage.textContent = msg;
    errorMessage.classList.remove('hidden');
  }

  function showError(msg) {
    hideLoader();
    heroSection.classList.add('hidden');
    bentoGrid.classList.add('hidden');
    loadMoreWrap.classList.add('hidden');
    if (sectionDivider) sectionDivider.classList.add('hidden');
    errorMessage.textContent = msg;
    errorMessage.classList.remove('hidden');
  }
});
