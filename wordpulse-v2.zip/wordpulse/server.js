'use strict';

const app = require('./src/app');

const PORT = process.env.PORT || 3000;

// Only start a listener when run directly (local dev / tests).
// On Vercel the app is imported by api/index.js and wrapped as a serverless function.
if (require.main === module) {
  const server = app.listen(PORT, () => {
    console.log(`WordPulse server is running on port ${PORT}`);
  });
  server.setTimeout(15000);
}

module.exports = app;
