'use strict';

const express = require('express');
const cors = require('cors');
const path = require('path');
const apiRoutes = require('./routes');
const logger = require('./logger');

const app = express();

app.use(cors());
app.use(express.json());

// Rate limiting: active only when Upstash Redis is configured.
// 60 requests per minute per IP, applied to /api/* only.
let ratelimit = null;
if (process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN) {
  try {
    const { Ratelimit } = require('@upstash/ratelimit');
    const { Redis } = require('@upstash/redis');
    ratelimit = new Ratelimit({
      redis: Redis.fromEnv(),
      limiter: Ratelimit.slidingWindow(60, '1 m'),
      prefix: 'rl'
    });
    logger.info('ratelimit: enabled (60 req/min per IP)');
  } catch (err) {
    logger.error({ err: err instanceof Error ? err.message : String(err) }, 'ratelimit: init failed');
  }
}

app.use('/api', async (req, res, next) => {
  if (!ratelimit) return next();
  try {
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    const { success, remaining } = await ratelimit.limit(ip);
    res.set('X-RateLimit-Remaining', String(remaining));
    if (!success) {
      return res.status(429).json({ error: 'Too many requests. Try again in a minute.' });
    }
  } catch (err) {
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'ratelimit: check failed, allowing request');
  }
  next();
});

// API Routes
app.use('/api', apiRoutes);

// Static + SPA fallback (used in local dev; on Vercel public/ is served by the CDN)
app.use(express.static(path.join(__dirname, '..', 'public')));
app.get(/(.*)/, (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

module.exports = app;
