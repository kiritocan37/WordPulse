'use strict';

const pino = require('pino');

/**
 * Structured logger. In Vercel, stdout JSON lines are indexed and searchable.
 * Level configurable via LOG_LEVEL env (default: info, silent in tests).
 */
const logger = pino({
  level: process.env.LOG_LEVEL || (process.env.NODE_ENV === 'test' ? 'silent' : 'info'),
  base: undefined,
  timestamp: pino.stdTimeFunctions.isoTime
});

module.exports = logger;
