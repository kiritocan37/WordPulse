'use strict';

const logger = require('./logger');
const store = require('./store');
const { fetchAllFeeds } = require('./feeds');
const { translateArticle, apiLang } = require('./translate');

const LANGS = ['en', 'ru', 'ua'];
const ARTICLES_TTL = 24 * 60 * 60;        // articles kept for 24h (refresh overwrites)
const FRESH_WINDOW = 10 * 60;             // consider data fresh for 10 min
const MAX_TRANSLATED = 48;                // cap translation work per language per refresh
const MAX_PER_SOURCE = 8;

// In-process guard so concurrent requests on a warm instance share one refresh
const inFlight = new Map();

/**
 * Apply the per-source diversity cap and sort newest-first.
 * @param {object[]} articles
 */
function diversify(articles) {
  const bySource = {};
  for (const a of articles) {
    if (!bySource[a.sourceId]) bySource[a.sourceId] = [];
    if (bySource[a.sourceId].length < MAX_PER_SOURCE) bySource[a.sourceId].push(a);
  }
  const result = Object.values(bySource).flat();
  result.sort((a, b) => new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime());
  return result;
}

/**
 * Translate the newest articles into one target language.
 * Translation results are individually cached in the store (7-day TTL),
 * so across refreshes only genuinely new articles cost API calls.
 * @param {object[]} articles
 * @param {string} lang
 */
async function buildLanguageEdition(articles, lang) {
  const normalized = apiLang(lang);
  const out = [];
  const CONCURRENCY = 5;

  for (let i = 0; i < articles.length; i += CONCURRENCY) {
    const chunk = articles.slice(i, i + CONCURRENCY);
    const results = await Promise.allSettled(
      chunk.map(a => {
        if (a.originalLang === normalized || out.length + chunk.length > MAX_TRANSLATED) {
          return Promise.resolve(a);
        }
        return translateArticle(a, lang);
      })
    );
    results.forEach((r, idx) => {
      out.push(r.status === 'fulfilled' ? r.value : chunk[idx]);
    });
  }
  return out;
}

/**
 * Full refresh: fetch all feeds once, build pre-translated editions for
 * every supported language, persist them to the store.
 * @returns {Promise<{count:number, langs:string[]}>}
 */
async function refreshAll() {
  const started = Date.now();
  const raw = await fetchAllFeeds();
  const articles = diversify(raw);

  for (const lang of LANGS) {
    const edition = await buildLanguageEdition(articles, lang);
    await store.set(`articles:${lang}`, { articles: edition, updatedAt: Date.now() }, ARTICLES_TTL);
  }

  logger.info({ count: articles.length, ms: Date.now() - started }, 'refresh: completed');
  return { count: articles.length, langs: LANGS };
}

/**
 * Refresh a single language edition (used as on-demand fallback when a
 * request arrives and the store is empty/stale and no cron has run yet).
 * @param {string} lang
 */
async function refreshLanguage(lang) {
  if (inFlight.has(lang)) return inFlight.get(lang);

  const promise = (async () => {
    const raw = await fetchAllFeeds();
    const articles = diversify(raw);
    const edition = await buildLanguageEdition(articles, lang);
    const payload = { articles: edition, updatedAt: Date.now() };
    await store.set(`articles:${lang}`, payload, ARTICLES_TTL);
    return payload;
  })();

  inFlight.set(lang, promise);
  try {
    return await promise;
  } finally {
    inFlight.delete(lang);
  }
}

/**
 * Get the edition for a language: served from the store when present,
 * refreshed on demand otherwise. Stale-while-usable: stale data is
 * returned immediately rather than blocking the request.
 * @param {string} lang
 * @returns {Promise<{articles: object[], updatedAt: number, stale: boolean}>}
 */
async function getEdition(lang) {
  const cached = await store.get(`articles:${lang}`);
  if (cached && Array.isArray(cached.articles) && cached.articles.length > 0) {
    const stale = (Date.now() - cached.updatedAt) / 1000 > FRESH_WINDOW;
    return { ...cached, stale };
  }
  const fresh = await refreshLanguage(lang);
  return { ...fresh, stale: false };
}

/**
 * Optional: post a daily digest to a Telegram channel.
 * Active only when TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID are configured.
 * @param {string} lang
 */
async function postTelegramDigest(lang = 'ua') {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) return { skipped: true };

  const edition = await getEdition(lang);
  const top = edition.articles.slice(0, 5);
  if (top.length === 0) return { skipped: true };

  const lines = top.map((a, i) => `${i + 1}. <a href="${a.link}">${escapeHtml(a.title)}</a> — ${a.source}`);
  const text = `<b>WordPulse · ${new Date().toLocaleDateString('uk-UA')}</b>\n\n${lines.join('\n')}`;

  const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: chatId,
      text,
      parse_mode: 'HTML',
      disable_web_page_preview: false
    })
  });
  if (!response.ok) {
    const body = await response.text();
    logger.error({ status: response.status, body }, 'telegram: sendMessage failed');
    return { ok: false };
  }
  return { ok: true, posted: top.length };
}

/**
 * @param {string} s
 */
function escapeHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

module.exports = { refreshAll, refreshLanguage, getEdition, diversify, postTelegramDigest };
