'use strict';

const express = require('express');
const router = express.Router();
const { FEED_SOURCES } = require('./feeds');
const { getEdition, refreshAll, postTelegramDigest } = require('./refresh');
const store = require('./store');
const logger = require('./logger');

const PAGE_SIZE = 18;
const MAX_LIMIT = 30;

const VALID_LANGS = new Set(['en', 'ru', 'ua']);
const VALID_CATEGORIES = new Set(['', 'world', 'politics', 'tech', 'culture']);
const COUNTRY_RE = /^[A-Za-z]{0,3}$/;

// GET /api/articles?lang=&country=&category=&offset=&limit=
router.get('/articles', async (req, res) => {
  try {
    const lang = String(req.query.lang || 'en').toLowerCase();
    const category = String(req.query.category || '').toLowerCase();
    const country = String(req.query.country || '');
    const offset = Math.max(0, parseInt(String(req.query.offset), 10) || 0);
    const limit = Math.min(MAX_LIMIT, Math.max(1, parseInt(String(req.query.limit), 10) || PAGE_SIZE));

    if (!VALID_LANGS.has(lang)) {
      return res.status(400).json({ error: `Invalid lang. Supported: ${[...VALID_LANGS].join(', ')}` });
    }
    if (!VALID_CATEGORIES.has(category)) {
      return res.status(400).json({ error: `Invalid category. Supported: ${[...VALID_CATEGORIES].filter(Boolean).join(', ')}` });
    }
    if (!COUNTRY_RE.test(country)) {
      return res.status(400).json({ error: 'Invalid country code' });
    }

    const edition = await getEdition(lang);
    let articles = edition.articles;

    if (country) {
      articles = articles.filter(a => a.country.toLowerCase() === country.toLowerCase());
    }
    if (category) {
      articles = articles.filter(a => a.category.toLowerCase() === category);
    }

    const total = articles.length;
    const paginated = articles.slice(offset, offset + limit);

    // Edge/CDN caching: each (lang, category, country, offset) combo is cached
    // at Vercel's edge for 10 min and served stale up to 30 min while revalidating.
    res.set('Cache-Control', 'public, s-maxage=600, stale-while-revalidate=1800');

    res.json({
      articles: paginated,
      total,
      offset,
      limit,
      hasMore: offset + paginated.length < total,
      updatedAt: edition.updatedAt
    });
  } catch (err) {
    logger.error({ err: err instanceof Error ? err.message : String(err) }, 'articles: failed');
    res.status(500).json({ error: 'Failed to fetch articles' });
  }
});

// GET /api/sources
router.get('/sources', (req, res) => {
  res.set('Cache-Control', 'public, s-maxage=3600, stale-while-revalidate=86400');
  res.json(FEED_SOURCES.map(s => ({
    id: s.id,
    name: s.name,
    country: s.country,
    language: s.language
  })));
});

// GET /api/health — for uptime monitoring (UptimeRobot etc.)
router.get('/health', async (req, res) => {
  const en = await store.get('articles:en');
  res.set('Cache-Control', 'no-store');
  res.json({
    status: 'ok',
    redis: store.usingRedis(),
    articlesCached: !!(en && en.articles && en.articles.length),
    lastRefresh: en && en.updatedAt ? new Date(en.updatedAt).toISOString() : null,
    uptime: Math.round(process.uptime())
  });
});

// GET /api/refresh — invoked by Vercel Cron (or manually with the secret).
// When CRON_SECRET is set, requires Authorization: Bearer <CRON_SECRET>
// (Vercel sends this header automatically for cron invocations).
router.get('/refresh', async (req, res) => {
  const secret = process.env.CRON_SECRET;
  if (secret) {
    const auth = req.headers['authorization'] || '';
    if (auth !== `Bearer ${secret}`) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
  }
  try {
    const result = await refreshAll();
    /** @type {any} */
    let telegram = { skipped: true };
    if (String(req.query.digest) === '1' || process.env.TELEGRAM_AUTO_DIGEST === '1') {
      telegram = await postTelegramDigest(process.env.TELEGRAM_DIGEST_LANG || 'ua');
    }
    res.set('Cache-Control', 'no-store');
    res.json({ ok: true, ...result, telegram });
  } catch (err) {
    logger.error({ err: err instanceof Error ? err.message : String(err) }, 'refresh: failed');
    res.status(500).json({ error: 'Refresh failed' });
  }
});

module.exports = router;
