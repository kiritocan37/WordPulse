'use strict';

const logger = require('./logger');

/**
 * Unified key-value store with TTL.
 *
 * - When UPSTASH_REDIS_REST_URL + UPSTASH_REDIS_REST_TOKEN are set,
 *   uses Upstash Redis: persistent, shared across all serverless instances.
 * - Otherwise falls back to an in-process Map (works locally and as a
 *   degraded-but-functional mode on Vercel until Redis is configured).
 */
const memory = new Map();

let redis = null;

function getRedis() {
  if (redis) return redis;
  if (process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN) {
    try {
      const { Redis } = require('@upstash/redis');
      redis = Redis.fromEnv();
      logger.info('store: using Upstash Redis');
    } catch (err) {
      logger.error({ err: err.message }, 'store: failed to init Redis, falling back to memory');
    }
  }
  return redis;
}

/**
 * @param {string} key
 * @returns {Promise<any|null>}
 */
async function get(key) {
  const r = getRedis();
  if (r) {
    try {
      return await r.get(key);
    } catch (err) {
      logger.error({ err: err.message, key }, 'store: redis get failed');
      return null;
    }
  }
  const entry = memory.get(key);
  if (!entry) return null;
  if (entry.exp && Date.now() > entry.exp) {
    memory.delete(key);
    return null;
  }
  return entry.value;
}

/**
 * @param {string} key
 * @param {any} value
 * @param {number} [ttlSeconds]
 */
async function set(key, value, ttlSeconds) {
  const r = getRedis();
  if (r) {
    try {
      if (ttlSeconds) {
        await r.set(key, value, { ex: ttlSeconds });
      } else {
        await r.set(key, value);
      }
      return;
    } catch (err) {
      logger.error({ err: err.message, key }, 'store: redis set failed');
      return;
    }
  }
  memory.set(key, { value, exp: ttlSeconds ? Date.now() + ttlSeconds * 1000 : null });
}

/** Test helper / local reset. */
function clearMemory() {
  memory.clear();
}

function usingRedis() {
  return !!getRedis();
}

module.exports = { get, set, clearMemory, usingRedis };
