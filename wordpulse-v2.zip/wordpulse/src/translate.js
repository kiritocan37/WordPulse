'use strict';

const logger = require('./logger');
const store = require('./store');

const TRANSLATION_TTL = 7 * 24 * 60 * 60; // 7 days

/**
 * Map app language codes to API language codes.
 * @param {string} lang
 */
function apiLang(lang) {
  return lang === 'ua' ? 'uk' : lang;
}

/**
 * Primary: DeepL API (official, reliable) — used when DEEPL_API_KEY is set.
 * @param {string} text
 * @param {string} targetLang - normalized (en/ru/uk)
 * @returns {Promise<string>}
 */
async function translateWithDeepL(text, targetLang) {
  const key = process.env.DEEPL_API_KEY;
  const endpoint = process.env.DEEPL_API_URL || 'https://api-free.deepl.com/v2/translate';
  const deeplTarget = targetLang === 'en' ? 'EN-US' : targetLang.toUpperCase();

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Authorization': `DeepL-Auth-Key ${key}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ text: [text], target_lang: deeplTarget }),
      signal: controller.signal
    });
    if (!response.ok) {
      throw new Error(`DeepL HTTP ${response.status}`);
    }
    const data = await response.json();
    const translated = data && data.translations && data.translations[0] && data.translations[0].text;
    if (!translated) throw new Error('DeepL: empty translation');
    return translated;
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Secondary: unofficial Google Translate scraper.
 * @param {string} text
 * @param {string} targetLang
 */
async function translateWithGoogle(text, targetLang) {
  const translate = /** @type {any} */ (require('google-translate-api-x'));
  const TIMEOUT = 4000;
  const res = await Promise.race([
    translate(text, { to: targetLang }),
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`Google translate timed out after ${TIMEOUT}ms`)), TIMEOUT)
    )
  ]);
  return res.text;
}

/**
 * Tertiary: public LibreTranslate instance.
 * @param {string} text
 * @param {string} targetLang
 */
async function translateWithLibre(text, targetLang) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch('https://libretranslate.de/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ q: text, source: 'auto', target: targetLang, format: 'text' }),
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`LibreTranslate HTTP ${response.status}`);
    const data = await response.json();
    if (!data.translatedText) throw new Error('LibreTranslate: empty translation');
    return data.translatedText;
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Translate text through the provider chain:
 * DeepL (if key configured) -> Google (unofficial) -> LibreTranslate.
 * Throws if every provider fails, so callers never cache untranslated text
 * as translated.
 * @param {string} text
 * @param {string} targetLang - app language code (en/ru/ua)
 * @returns {Promise<string>}
 */
async function translateText(text, targetLang) {
  if (!text) return text;
  const lang = apiLang(targetLang);

  /** @type {Array<[string, (text: string, lang: string) => Promise<string>]>} */
  const providers = [];
  if (process.env.DEEPL_API_KEY) {
    providers.push(['deepl', translateWithDeepL]);
  }
  providers.push(['google', translateWithGoogle]);
  providers.push(['libre', translateWithLibre]);

  let lastErr = null;
  for (const [name, fn] of providers) {
    try {
      return await fn(text, lang);
    } catch (err) {
      lastErr = err;
      logger.warn({ provider: name, err: err.message }, `translate: provider failed`);
    }
  }
  throw new Error(`All translation services failed: ${lastErr ? lastErr.message : 'unknown'}`);
}

/**
 * Stable cache key for an article + language pair.
 * @param {object} article
 * @param {string} lang
 */
function translationKey(article, lang) {
  const id = article.link || article.title;
  // Simple djb2 hash keeps keys short and Redis-safe
  let hash = 5381;
  for (let i = 0; i < id.length; i++) {
    hash = ((hash << 5) + hash + id.charCodeAt(i)) | 0;
  }
  return `tr:${lang}:${hash >>> 0}`;
}

/**
 * Translate an article's title and description into targetLang,
 * with persistent caching (7-day TTL). Returns the original article
 * if it is already in the target language.
 * @param {object} article
 * @param {string} targetLang - app language code (en/ru/ua)
 * @returns {Promise<object>}
 */
async function translateArticle(article, targetLang) {
  const lang = (targetLang || 'en').toLowerCase();
  const normalized = apiLang(lang);

  if (normalized === article.originalLang) return article;

  const cacheKey = translationKey(article, normalized);
  const cached = await store.get(cacheKey);
  if (cached && cached.title) {
    return { ...article, title: cached.title, description: cached.description };
  }

  const [title, description] = await Promise.all([
    translateText(article.title, lang),
    translateText(article.description, lang)
  ]);

  await store.set(cacheKey, { title, description }, TRANSLATION_TTL);
  return { ...article, title, description };
}

module.exports = {
  translateText,
  translateArticle,
  translationKey,
  apiLang
};
