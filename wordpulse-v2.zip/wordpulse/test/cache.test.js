'use strict';

process.env.NODE_ENV = 'test';

const { test } = require('node:test');
const assert = require('node:assert');
const { Cache } = require('../src/cache');

test('cache stores and expires by TTL', async () => {
  const cache = new Cache(50); // 50ms TTL
  cache.set('k', 'v');
  assert.equal(cache.get('k'), 'v');
  await new Promise(r => setTimeout(r, 80));
  assert.equal(cache.get('k'), null);
});

test('getOrFetch shares in-flight promise (stampede protection)', async () => {
  const cache = new Cache(1000);
  let calls = 0;
  const fetchFn = () => new Promise(resolve => {
    calls++;
    setTimeout(() => resolve('data'), 30);
  });
  const [a, b, c] = await Promise.all([
    cache.getOrFetch('key', fetchFn),
    cache.getOrFetch('key', fetchFn),
    cache.getOrFetch('key', fetchFn)
  ]);
  assert.equal(calls, 1);
  assert.equal(a, 'data');
  assert.equal(b, 'data');
  assert.equal(c, 'data');
});

test('getOrFetch does not cache failures', async () => {
  const cache = new Cache(1000);
  let calls = 0;
  const failing = () => { calls++; return Promise.reject(new Error('boom')); };
  await assert.rejects(() => cache.getOrFetch('k', failing));
  const ok = () => { calls++; return Promise.resolve('recovered'); };
  assert.equal(await cache.getOrFetch('k', ok), 'recovered');
  assert.equal(calls, 2);
});
