'use strict';

process.env.NODE_ENV = 'test';

const { test, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert');
const { mockFeeds, setupNetwork, teardownNetwork } = require('./helpers');
const { fetchFeed, fetchAllFeeds, categorizeArticle, extractImage, FEED_SOURCES } = require('../src/feeds');

beforeEach(() => {
  setupNetwork();
  mockFeeds();
});

afterEach(() => {
  teardownNetwork();
});

test('fetchFeed parses BBC fixture into article schema', async () => {
  const bbc = FEED_SOURCES.find(s => s.id === 'bbc');
  const articles = await fetchFeed(bbc);
  assert.equal(articles.length, 3);
  const first = articles[0];
  assert.equal(first.source, 'BBC World');
  assert.equal(first.country, 'UK');
  assert.equal(first.originalLang, 'en');
  assert.ok(first.title.length > 0);
  assert.ok(first.link.startsWith('https://'));
});

test('fetchFeed returns [] when feed fails (no fallback)', async () => {
  const lemonde = FEED_SOURCES.find(s => s.id === 'lemonde');
  const articles = await fetchFeed(lemonde);
  assert.deepEqual(articles, []);
});

test('fetchAllFeeds survives 7 of 8 feeds failing', async () => {
  const articles = await fetchAllFeeds();
  assert.ok(articles.length >= 3);
  assert.ok(articles.every(a => a.sourceId === 'bbc'));
});

test('categorizeArticle detects tech / politics / default', () => {
  const source = { defaultCategory: 'world' };
  assert.equal(categorizeArticle({ title: 'New AI software startup', categories: [] }, source), 'tech');
  assert.equal(categorizeArticle({ title: 'Parliament election vote', categories: [] }, source), 'politics');
  assert.equal(categorizeArticle({ title: 'Something unrelated entirely', categories: [] }, source), 'world');
});

test('categorizeArticle works with multilingual keywords', () => {
  const source = { defaultCategory: 'world' };
  assert.equal(categorizeArticle({ title: 'Вибори до парламенту', categories: [] }, source), 'politics');
  assert.equal(categorizeArticle({ title: 'Sztuczna inteligencja w biznesie', categories: [] }, source), 'tech');
});

test('extractImage handles enclosure, media:thumbnail, inline img, and none', () => {
  assert.equal(extractImage({ enclosure: { url: 'https://x/a.jpg' } }), 'https://x/a.jpg');
  assert.equal(extractImage({ 'media:thumbnail': { $: { url: 'https://x/b.jpg' } } }), 'https://x/b.jpg');
  assert.equal(extractImage({ content: '<p><img src="https://x/c.jpg"></p>' }), 'https://x/c.jpg');
  assert.equal(extractImage({}), null);
});
