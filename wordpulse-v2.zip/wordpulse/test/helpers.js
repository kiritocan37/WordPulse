'use strict';

const nock = require('nock');
const fs = require('fs');
const path = require('path');
const { FEED_SOURCES } = require('../src/feeds');

const BBC_XML = fs.readFileSync(path.join(__dirname, 'fixtures', 'bbc.xml'), 'utf8');

/**
 * Mock every configured feed host: BBC returns the fixture,
 * everything else returns 500 (resilience path).
 */
function mockFeeds() {
  for (const source of FEED_SOURCES) {
    for (const url of [source.feedUrl, source.fallbackUrl]) {
      if (!url) continue;
      const u = new URL(url);
      const scope = nock(u.origin).persist().get(u.pathname + u.search);
      if (source.id === 'bbc') {
        scope.reply(200, BBC_XML, { 'Content-Type': 'application/xml' });
      } else {
        scope.reply(500, 'unavailable');
      }
    }
  }
}

function setupNetwork() {
  nock.disableNetConnect();
  nock.enableNetConnect(host => host.includes('127.0.0.1') || host.includes('localhost'));
}

function teardownNetwork() {
  nock.cleanAll();
  nock.enableNetConnect();
}

module.exports = { mockFeeds, setupNetwork, teardownNetwork, BBC_XML };
