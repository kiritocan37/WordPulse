'use strict';

process.env.NODE_ENV = 'test';

const { test, beforeEach } = require('node:test');
const assert = require('node:assert');
const store = require('../src/store');

beforeEach(() => store.clearMemory());

test('store falls back to memory without Redis env', async () => {
  assert.equal(store.usingRedis(), false);
});

test('store set/get round-trip with objects', async () => {
  await store.set('obj', { a: 1, nested: { b: 2 } });
  assert.deepEqual(await store.get('obj'), { a: 1, nested: { b: 2 } });
});

test('store respects TTL', async () => {
  await store.set('temp', 'value', 0.05); // 50ms
  assert.equal(await store.get('temp'), 'value');
  await new Promise(r => setTimeout(r, 80));
  assert.equal(await store.get('temp'), null);
});

test('store returns null for missing keys', async () => {
  assert.equal(await store.get('nope'), null);
});
