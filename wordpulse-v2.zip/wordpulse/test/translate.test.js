'use strict';

process.env.NODE_ENV = 'test';

const { test } = require('node:test');
const assert = require('node:assert');
const { translateArticle, translationKey, apiLang } = require('../src/translate');

test('apiLang maps ua -> uk and passes others through', () => {
  assert.equal(apiLang('ua'), 'uk');
  assert.equal(apiLang('en'), 'en');
  assert.equal(apiLang('ru'), 'ru');
});

test('translateArticle skips when article is already in target language', async () => {
  const article = { title: 'T', description: 'D', originalLang: 'en', link: 'https://x/1' };
  const result = await translateArticle(article, 'en');
  assert.strictEqual(result, article); // same reference: no work performed
});

test('translateArticle skips ua target for uk-language source', async () => {
  const article = { title: 'Т', description: 'Д', originalLang: 'uk', link: 'https://x/2' };
  const result = await translateArticle(article, 'ua');
  assert.strictEqual(result, article);
});

test('translationKey is stable and language-scoped', () => {
  const a = { link: 'https://example.com/article' };
  assert.equal(translationKey(a, 'ru'), translationKey(a, 'ru'));
  assert.notEqual(translationKey(a, 'ru'), translationKey(a, 'uk'));
});
