# Changelog

## [3.0.0] — 2026-06-10

### Fixed
- **Offline notice was invisible**: the render path hid it immediately after it was shown — notices now use a dedicated banner element, displayed after rendering
- **Background revalidation never ran on Vercel**: serverless freezes after the response, so the fire-and-forget refresh silently died — now kept alive via `@vercel/functions` `waitUntil` (graceful fallback elsewhere)
- An empty feed pass can no longer overwrite a good stored edition with nothing

### Changed
- Image enrichment and translation now run **in parallel** (independent fields) — on-demand refresh roughly 15s faster
- On-demand refresh uses a lighter og-scrape budget (12 pages) vs the cron path (30) to keep request-path latency bounded
- Relative og:image URLs are resolved against the article URL
- Removed dead code: legacy in-memory `Cache` module and feeds' module-level memory (the store layer made both redundant)
- Telegram digest now escapes links/sources, not just titles

### Added
- Security headers (API + static via vercel.json), `x-powered-by` disabled
- Immutable 1-year caching for fonts and icons
- CLS-free images via CSS `aspect-ratio` (cards 16:9, hero 2.2:1)
- "· updated Xm ago" indicator next to the edition date
- `aria-pressed` state on all filter buttons; offline navigation fallback in the service worker
- `.gitignore`, MIT `LICENSE`, package metadata (engines, repository, author)
- Tests for diversify, image-enrichment caching, fresh-edition serving, relative URL resolution — 36 total

## [2.1.0] — 2026-06-10

### Fixed
- Articles beyond the translation cap appeared untranslated in the feed — editions are now capped at 60 articles and EVERY article in an edition is translated
- Stale editions were detected but never refreshed — now: fresh (<10 min) served as-is, soft-stale (10–60 min) served instantly with background revalidation, hard-stale (>60 min) refreshed before responding, with fallback to stale data if refresh fails

### Added
- **og:image scraping** (`src/scrape.js`): articles whose RSS feed has no image get their photo extracted from the article page itself (og:image / twitter:image), streaming-fetched with a 3.5s timeout and 250KB read cap; results cached 7 days so each page is visited once
- **Batched translation**: titles+descriptions for a whole edition are translated in a handful of HTTP requests (DeepL: 40 texts/request, Google: 15) instead of 2 requests per article — a full 3-language refresh went from ~240 potential calls to ~10-15
- Descriptions truncated at 400 chars at ingestion (word boundary) — saves translation quota
- Function maxDuration raised to 60s for the refresh path
- 7 new tests (scrape extraction, translation caching, graceful provider failure) — 34 total

## [2.0.0] — 2026-06-10

### Architecture
- Storage abstraction (`src/store.js`): Upstash Redis when configured, in-memory fallback otherwise
- Pre-translated language editions built by `src/refresh.js`; `/api/articles` is now a pure read
- `/api/refresh` cron endpoint (Vercel Cron, daily) with `CRON_SECRET` protection
- DeepL API as primary translation provider, Google (unofficial) and LibreTranslate as fallbacks
- Persistent 7-day translation cache — only new articles cost translation calls
- Rate limiting (60 req/min per IP) when Redis is configured
- `/api/health` endpoint for uptime monitoring
- Query parameter validation (400 on invalid lang/category/country)
- Structured JSON logging via pino

### Frontend
- Image proxy (weserv.nl): article images resized + converted to WebP
- Skeleton loaders replacing the text loader
- Bookmarks: save articles to localStorage, "Saved" view
- PWA: manifest, icons, service worker with offline support
- Self-hosted fonts (latin + latin-ext + cyrillic subsets), no Google Fonts requests
- Visible keyboard focus styles, `prefers-reduced-motion` support

### Tooling
- Offline test suite (27 tests): node:test + nock fixtures + supertest
- ESLint (flat config) + Prettier
- Type checking via `tsc --noEmit` with `checkJs` (JSDoc-driven)
- GitHub Actions CI: lint + typecheck + tests on every push/PR

## [1.1.0] — 2026-06-10

- Serverless restructure (api/index.js entry, CDN-served static files)
- Edge caching via Cache-Control s-maxage on API responses
- Pagination with Load more; per-source diversity cap
- New sources: NYT (replacing dead Reuters PR feed), Українська правда, Polsat News
- Article images rendered (hero banner + card covers)
- Full UI localization (EN/RU/UA), persisted language preference
- Relative timestamps, word-boundary truncation
- Meta/OG tags, favicon, unified WordPulse naming

## [1.0.0]

- Initial release
