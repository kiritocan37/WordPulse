'use strict';

const logger = require('./logger');
const store = require('./store');
const { fetchAllFeeds } = require('./feeds');
const { translateArticles } = require('./translate');
const { scrapeOgImage } = require('./scrape');

const LANGS = ['en', 'ru', 'ua'];
const ARTICLES_TTL = 24 * 60 * 60;   // editions kept 24h (refresh overwrites)
const FRESH_WINDOW = 10 * 60;        // fresh for 10 min
const HARD_STALE = 60 * 60;          // older than 1h → refresh before responding
const EDITION_SIZE = 60;             // edition cap: every article in it IS translated
const MAX_PER_SOURCE = 8;
const OG_LIMIT_FULL = 30;            // cron path: scrape up to 30 article pages
const OG_LIMIT_LIGHT = 12;           // request path: keep on-demand refresh fast
const OG_CONCURRENCY = 6;
const OG_TTL = 7 * 24 * 60 * 60;

// Vercel: lets background work outlive the response. Falls back gracefully
// when unavailable (local dev, other hosts).
let vercelWaitUntil = null;
try {
  vercelWaitUntil = require('@vercel/functions').waitUntil;
} catch {
  // not running on Vercel / package unavailable — background() degrades below
}

/**
 * Run a promise in the background without blocking the response.
 * @param {Promise<any>} promise
 */
function background(promise) {
  const guarded = promise.catch((err) =>
    logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'background task failed')
  );
  if (vercelWaitUntil) {
    try {
      vercelWaitUntil(guarded);
      return;
    } catch {
      // outside a request context — fall through
    }
  }
  // Local dev: the event loop keeps it alive naturally
}

// In-process guards so concurrent requests on a warm instance share work
const inFlight = new Map();

/**
 * Per-source diversity cap + newest-first sort + edition size cap.
 * @param {object[]} articles
 */
function diversify(articles) {
  const bySource = {};
  for (const a of articles) {
    if (!bySource[a.sourceId]) bySource[a.sourceId] = [];
    if (bySource[a.sourceId].length < MAX_PER_SOURCE) bySource[a.sourceId].push(a);
  }
  const result = Object.values(bySource).flat();
  result.sort((a, b) => new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime());
  return result.slice(0, EDITION_SIZE);
}

/**
 * @param {string} link
 */
function ogKey(link) {
  let hash = 5381;
  for (let i = 0; i < link.length; i++) {
    hash = ((hash << 5) + hash + link.charCodeAt(i)) | 0;
  }
  return `og:${hash >>> 0}`;
}

/**
 * Fill missing article images by scraping og:image from the article pages.
 * Results (including "no image found") are cached for 7 days, so each page
 * is visited at most once. Bounded, concurrent, never throws.
 * @param {object[]} articles - mutated in place
 * @param {number} [limit]
 */
async function enrichImages(articles, limit = OG_LIMIT_FULL) {
  if (process.env.DISABLE_OG_SCRAPE === '1') return;

  const missing = articles.filter(a => !a.imageUrl && a.link);
  if (missing.length === 0) return;

  // Apply cached scrape results first (parallel reads)
  const cached = await Promise.all(missing.map(a => store.get(ogKey(a.link))));
  const toScrape = [];
  missing.forEach((a, idx) => {
    const hit = cached[idx];
    if (hit === 'none') return;        // known: page has no og:image
    if (typeof hit === 'string' && hit) {
      a.imageUrl = hit;
      return;
    }
    toScrape.push(a);
  });

  const queue = toScrape.slice(0, limit);
  let found = 0;

  for (let i = 0; i < queue.length; i += OG_CONCURRENCY) {
    const batch = queue.slice(i, i + OG_CONCURRENCY);
    await Promise.all(batch.map(async (a) => {
      const img = await scrapeOgImage(a.link);
      if (img) {
        a.imageUrl = img;
        found++;
      }
      await store.set(ogKey(a.link), img || 'none', OG_TTL);
    }));
  }

  if (queue.length > 0) {
    logger.info({ attempted: queue.length, found }, 'refresh: og:image enrichment');
  }
}

/**
 * Fetch + diversify once, then build translated editions for the given
 * languages. Image enrichment and translation touch different fields,
 * so they run IN PARALLEL; discovered images are re-applied to the
 * translated copies afterwards.
 * @param {string[]} langs
 * @param {number} ogLimit
 * @returns {Promise<{articles: object[], editions: Map<string, object[]>}>}
 */
async function buildEditions(langs, ogLimit) {
  const raw = await fetchAllFeeds();
  const articles = diversify(raw);
  if (articles.length === 0) {
    return { articles, editions: new Map() };
  }

  const [translatedPerLang] = await Promise.all([
    Promise.all(langs.map(lang => translateArticles(articles, lang))),
    enrichImages(articles, ogLimit)
  ]);

  const editions = new Map();
  langs.forEach((lang, li) => {
    const edition = translatedPerLang[li];
    edition.forEach((e, i) => { e.imageUrl = articles[i].imageUrl; });
    editions.set(lang, edition);
  });
  return { articles, editions };
}

/**
 * Full refresh (cron path): one feed pass, fully-translated edition per
 * language, full image enrichment.
 * @returns {Promise<{count:number, langs:string[]}>}
 */
async function refreshAll() {
  const started = Date.now();
  const { articles, editions } = await buildEditions(LANGS, OG_LIMIT_FULL);

  if (articles.length > 0) {
    const now = Date.now();
    await Promise.all(LANGS.map(lang =>
      store.set(`articles:${lang}`, { articles: editions.get(lang), updatedAt: now }, ARTICLES_TTL)
    ));
  } else {
    logger.warn('refresh: all feeds returned 0 articles — keeping previous editions');
  }

  logger.info({ count: articles.length, ms: Date.now() - started }, 'refresh: completed');
  return { count: articles.length, langs: LANGS };
}

/**
 * Refresh a single language edition (on-demand path, lighter og scraping).
 * Never overwrites a good edition with an empty one.
 * @param {string} lang
 */
async function refreshLanguage(lang) {
  if (inFlight.has(lang)) return inFlight.get(lang);

  const promise = (async () => {
    const { articles, editions } = await buildEditions([lang], OG_LIMIT_LIGHT);
    if (articles.length === 0) {
      const previous = await store.get(`articles:${lang}`);
      if (previous && Array.isArray(previous.articles) && previous.articles.length > 0) {
        return previous;
      }
      return { articles: [], updatedAt: Date.now() };
    }
    const payload = { articles: editions.get(lang), updatedAt: Date.now() };
    await store.set(`articles:${lang}`, payload, ARTICLES_TTL);
    return payload;
  })();

  inFlight.set(lang, promise);
  try {
    return await promise;
  } finally {
    inFlight.delete(lang);
  }
}

/**
 * Get the edition for a language.
 * - fresh (<10 min): serve as-is
 * - soft-stale (10–60 min): serve immediately, revalidate in the background
 *   (kept alive via Vercel waitUntil when available)
 * - hard-stale (>60 min) or missing: refresh before responding,
 *   falling back to the stale edition if the refresh fails
 * @param {string} lang
 * @returns {Promise<{articles: object[], updatedAt: number}>}
 */
async function getEdition(lang) {
  const cached = await store.get(`articles:${lang}`);
  if (cached && Array.isArray(cached.articles) && cached.articles.length > 0) {
    const ageSec = (Date.now() - cached.updatedAt) / 1000;
    if (ageSec <= FRESH_WINDOW) return cached;
    if (ageSec <= HARD_STALE) {
      background(refreshLanguage(lang));
      return cached;
    }
  }
  try {
    return await refreshLanguage(lang);
  } catch (err) {
    if (cached && Array.isArray(cached.articles) && cached.articles.length > 0) {
      logger.warn({ lang }, 'refresh: failed, serving hard-stale edition');
      return cached;
    }
    throw err;
  }
}

/**
 * Optional: post a daily digest to a Telegram channel.
 * Active only when TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID are configured.
 * @param {string} lang
 */
async function postTelegramDigest(lang = 'ua') {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) return { skipped: true };

  const edition = await getEdition(lang);
  const top = edition.articles.slice(0, 5);
  if (top.length === 0) return { skipped: true };

  const lines = top.map((a, i) =>
    `${i + 1}. <a href="${escapeHtml(a.link)}">${escapeHtml(a.title)}</a> — ${escapeHtml(a.source)}`
  );
  const text = `<b>WordPulse · ${new Date().toLocaleDateString('uk-UA')}</b>\n\n${lines.join('\n')}`;

  const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: chatId,
      text,
      parse_mode: 'HTML',
      disable_web_page_preview: false
    })
  });
  if (!response.ok) {
    const body = await response.text();
    logger.error({ status: response.status, body }, 'telegram: sendMessage failed');
    return { ok: false };
  }
  return { ok: true, posted: top.length };
}

/**
 * @param {string} s
 */
function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

module.exports = { refreshAll, refreshLanguage, getEdition, diversify, enrichImages, ogKey, postTelegramDigest };
