'use strict';

const logger = require('./logger');

const FETCH_TIMEOUT = 3500;
const MAX_HTML_BYTES = 250 * 1024; // read at most 250KB — og tags live in <head>

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

/**
 * Extract the best preview image URL from page HTML.
 * Checks og:image, twitter:image, and link rel=image_src, in that order.
 * Pure function — easy to test without network.
 * @param {string} html
 * @returns {string|null}
 */
function extractOgImageFromHtml(html, baseUrl) {
  if (!html) return null;

  const patterns = [
    /<meta[^>]+property=["']og:image(?::secure_url)?["'][^>]+content=["']([^"']+)["']/i,
    /<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image(?::secure_url)?["']/i,
    /<meta[^>]+name=["']twitter:image(?::src)?["'][^>]+content=["']([^"']+)["']/i,
    /<meta[^>]+content=["']([^"']+)["'][^>]+name=["']twitter:image(?::src)?["']/i,
    /<link[^>]+rel=["']image_src["'][^>]+href=["']([^"']+)["']/i
  ];

  for (const re of patterns) {
    const match = html.match(re);
    if (!match || !match[1]) continue;
    const raw = match[1].replace(/&amp;/g, '&');
    try {
      const abs = new URL(raw, baseUrl || undefined).toString();
      if (/^https?:\/\//i.test(abs)) return abs;
    } catch {
      // not a resolvable URL — try the next pattern
    }
  }
  return null;
}

/**
 * Fetch an article page and extract its og:image.
 * Bounded: 3.5s timeout, reads at most 250KB of the response.
 * Never throws — returns null on any failure.
 * @param {string} url
 * @returns {Promise<string|null>}
 */
async function scrapeOgImage(url) {
  if (!url || !/^https?:\/\//i.test(url)) return null;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), FETCH_TIMEOUT);

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      redirect: 'follow',
      headers: { 'User-Agent': UA, 'Accept': 'text/html' }
    });
    if (!response.ok || !response.body) return null;

    // Stream just enough of the page to cover <head>
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let html = '';
    let bytes = 0;
    while (bytes < MAX_HTML_BYTES) {
      const { done, value } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      html += decoder.decode(value, { stream: true });
      // Early exit once head is closed — og tags are behind us
      if (html.includes('</head>')) break;
    }
    await reader.cancel().catch(() => {});

    return extractOgImageFromHtml(html, response.url || url);
  } catch (err) {
    logger.debug({ url, err: err instanceof Error ? err.message : String(err) }, 'scrape: og:image failed');
    return null;
  } finally {
    clearTimeout(timeoutId);
  }
}

module.exports = { scrapeOgImage, extractOgImageFromHtml };
