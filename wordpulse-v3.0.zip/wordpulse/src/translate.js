'use strict';

const logger = require('./logger');
const store = require('./store');

const TRANSLATION_TTL = 7 * 24 * 60 * 60; // 7 days
const DEEPL_CHUNK = 40;   // DeepL allows up to 50 texts per request
const GOOGLE_CHUNK = 15;  // keep unofficial batch payloads modest

/**
 * Map app language codes to API language codes.
 * @param {string} lang
 */
function apiLang(lang) {
  return lang === 'ua' ? 'uk' : lang;
}

/**
 * @param {any[]} arr
 * @param {number} size
 */
function chunk(arr, size) {
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

/**
 * DeepL batch translation (official API, used when DEEPL_API_KEY is set).
 * @param {string[]} texts
 * @param {string} targetLang - normalized (en/ru/uk)
 * @returns {Promise<string[]>}
 */
async function deeplBatch(texts, targetLang) {
  const key = process.env.DEEPL_API_KEY;
  const endpoint = process.env.DEEPL_API_URL || 'https://api-free.deepl.com/v2/translate';
  const deeplTarget = targetLang === 'en' ? 'EN-US' : targetLang.toUpperCase();

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 9000);
  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Authorization': `DeepL-Auth-Key ${key}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ text: texts, target_lang: deeplTarget }),
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`DeepL HTTP ${response.status}`);
    const data = await response.json();
    if (!data.translations || data.translations.length !== texts.length) {
      throw new Error('DeepL: response length mismatch');
    }
    return data.translations.map((/** @type {any} */ t) => t.text);
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Google batch translation (unofficial). Arrays in, arrays out —
 * one HTTP request per chunk instead of one per text.
 * @param {string[]} texts
 * @param {string} targetLang
 * @returns {Promise<string[]>}
 */
async function googleBatch(texts, targetLang) {
  const translate = /** @type {any} */ (require('google-translate-api-x'));
  const TIMEOUT = 8000;
  const res = await Promise.race([
    translate(texts, { to: targetLang, forceBatch: true }),
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`Google batch timed out after ${TIMEOUT}ms`)), TIMEOUT)
    )
  ]);
  const arr = Array.isArray(res) ? res : [res];
  if (arr.length !== texts.length) throw new Error('Google: response length mismatch');
  return arr.map((/** @type {any} */ r) => r.text);
}

/**
 * LibreTranslate single-text translation (last resort, sequential).
 * @param {string} text
 * @param {string} targetLang
 */
async function libreSingle(text, targetLang) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch('https://libretranslate.de/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ q: text, source: 'auto', target: targetLang, format: 'text' }),
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`LibreTranslate HTTP ${response.status}`);
    const data = await response.json();
    if (!data.translatedText) throw new Error('LibreTranslate: empty translation');
    return data.translatedText;
  } finally {
    clearTimeout(timeoutId);
  }
}

/**
 * Translate an array of texts through the provider chain, in batches:
 *   DeepL (if key) → Google (unofficial) → LibreTranslate (singles).
 * Returns an array of the same length; positions that could not be
 * translated by ANY provider are null (caller keeps the original).
 * @param {string[]} texts
 * @param {string} targetLang - app language code (en/ru/ua)
 * @returns {Promise<(string|null)[]>}
 */
async function translateBatch(texts, targetLang) {
  if (texts.length === 0) return [];
  // Kill-switch for tests/CI: behave as if every provider failed
  if (process.env.TRANSLATE_DISABLED === '1') {
    return new Array(texts.length).fill(null);
  }
  const lang = apiLang(targetLang);
  /** @type {(string|null)[]} */
  const results = new Array(texts.length).fill(null);

  // Work in chunks; remember each chunk's offset into the original array
  const size = process.env.DEEPL_API_KEY ? DEEPL_CHUNK : GOOGLE_CHUNK;
  const chunks = chunk(texts, size);
  let offset = 0;

  for (const part of chunks) {
    const base = offset;
    offset += part.length;
    let translated = null;

    if (process.env.DEEPL_API_KEY) {
      try {
        translated = await deeplBatch(part, lang);
      } catch (err) {
        logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'translate: DeepL batch failed');
      }
    }
    if (!translated) {
      try {
        translated = await googleBatch(part, lang);
      } catch (err) {
        logger.warn({ err: err instanceof Error ? err.message : String(err) }, 'translate: Google batch failed');
      }
    }
    if (!translated) {
      // Last resort: sequential singles via Libre; tolerate per-text failure
      translated = [];
      for (const text of part) {
        try {
          translated.push(await libreSingle(text, lang));
        } catch {
          translated.push(null);
        }
      }
    }

    translated.forEach((t, i) => { results[base + i] = t; });
  }

  return results;
}

/**
 * Stable cache key for an article + language pair.
 * @param {{link?: string, title?: string}} article
 * @param {string} lang
 */
function translationKey(article, lang) {
  const id = article.link || article.title || '';
  let hash = 5381;
  for (let i = 0; i < id.length; i++) {
    hash = ((hash << 5) + hash + id.charCodeAt(i)) | 0;
  }
  return `tr:${lang}:${hash >>> 0}`;
}

/**
 * Translate a list of articles into targetLang with full coverage:
 * 1. Articles already in the target language pass through untouched.
 * 2. Cached translations (7-day TTL) are applied without any API call.
 * 3. Remaining titles+descriptions are translated in BATCHES — a whole
 *    edition costs a handful of HTTP requests, not hundreds.
 * 4. Successful translations are cached; failures keep the original text.
 * @param {object[]} articles
 * @param {string} targetLang - app language code (en/ru/ua)
 * @returns {Promise<object[]>}
 */
async function translateArticles(articles, targetLang) {
  const normalized = apiLang(targetLang);
  const out = articles.map(a => ({ ...a }));

  // Which articles need work?
  const candidates = [];
  for (let i = 0; i < out.length; i++) {
    if (out[i].originalLang !== normalized) candidates.push(i);
  }
  if (candidates.length === 0) return out;

  // Apply cached translations (parallel reads)
  const cacheKeys = candidates.map(i => translationKey(out[i], normalized));
  const cached = await Promise.all(cacheKeys.map(k => store.get(k)));
  const misses = [];
  candidates.forEach((i, idx) => {
    const hit = cached[idx];
    if (hit && hit.title) {
      out[i].title = hit.title;
      out[i].description = hit.description;
    } else {
      misses.push(i);
    }
  });
  if (misses.length === 0) return out;

  // Batch-translate the misses
  /** @type {{i: number, field: string}[]} */
  const slots = [];
  /** @type {string[]} */
  const texts = [];
  for (const i of misses) {
    if (out[i].title) { slots.push({ i, field: 'title' }); texts.push(out[i].title); }
    if (out[i].description) { slots.push({ i, field: 'description' }); texts.push(out[i].description); }
  }

  const translated = await translateBatch(texts, targetLang);

  const failedArticles = new Set();
  translated.forEach((text, k) => {
    const { i, field } = slots[k];
    if (text) {
      out[i][field] = text;
    } else {
      failedArticles.add(i);
    }
  });

  // Cache fully-translated articles only
  await Promise.all(
    misses
      .filter(i => !failedArticles.has(i))
      .map(i => store.set(translationKey(out[i], normalized), {
        title: out[i].title,
        description: out[i].description
      }, TRANSLATION_TTL))
  );

  const failed = failedArticles.size;
  if (failed > 0) {
    logger.warn({ failed, total: misses.length }, 'translate: some articles kept original language');
  }
  return out;
}

/**
 * Single-article translation (kept for compatibility / ad-hoc use).
 * @param {object} article
 * @param {string} targetLang
 */
async function translateArticle(article, targetLang) {
  const [result] = await translateArticles([article], targetLang);
  return result;
}

module.exports = {
  translateArticles,
  translateArticle,
  translateBatch,
  translationKey,
  apiLang
};
