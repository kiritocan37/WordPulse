'use strict';

process.env.NODE_ENV = 'test';
process.env.TRANSLATE_DISABLED = '1';
process.env.DISABLE_OG_SCRAPE = '1';

const { test, before, after } = require('node:test');
const assert = require('node:assert');
const supertest = require('supertest');
const { mockFeeds, setupNetwork, teardownNetwork } = require('./helpers');
const app = require('../src/app');
const store = require('../src/store');

before(() => {
  setupNetwork();
  mockFeeds();
  store.clearMemory();
});

after(() => {
  teardownNetwork();
});

test('GET /api/articles returns paginated shape with edge cache header', async () => {
  const res = await supertest(app).get('/api/articles?lang=en&limit=2');
  assert.equal(res.status, 200);
  assert.match(res.headers['cache-control'], /s-maxage=600/);
  assert.ok(Array.isArray(res.body.articles));
  assert.equal(res.body.articles.length, 2);
  assert.equal(typeof res.body.total, 'number');
  assert.equal(typeof res.body.hasMore, 'boolean');
  assert.ok(res.body.updatedAt > 0);
});

test('GET /api/articles pagination offset works', async () => {
  const page1 = await supertest(app).get('/api/articles?lang=en&limit=1&offset=0');
  const page2 = await supertest(app).get('/api/articles?lang=en&limit=1&offset=1');
  assert.notEqual(page1.body.articles[0].link, page2.body.articles[0].link);
});

test('GET /api/articles filters by category', async () => {
  const res = await supertest(app).get('/api/articles?lang=en&category=tech');
  assert.equal(res.status, 200);
  assert.ok(res.body.articles.every(a => a.category === 'tech'));
});

test('GET /api/articles rejects invalid lang with 400', async () => {
  const res = await supertest(app).get('/api/articles?lang=zz');
  assert.equal(res.status, 400);
});

test('GET /api/articles rejects invalid category with 400', async () => {
  const res = await supertest(app).get('/api/articles?category=spam');
  assert.equal(res.status, 400);
});

test('GET /api/articles rejects invalid country with 400', async () => {
  const res = await supertest(app).get('/api/articles?country=NOTACODE');
  assert.equal(res.status, 400);
});

test('GET /api/sources lists all 8 sources', async () => {
  const res = await supertest(app).get('/api/sources');
  assert.equal(res.status, 200);
  assert.equal(res.body.length, 8);
  assert.ok(res.body.some(s => s.id === 'pravda'));
  assert.ok(res.body.some(s => s.id === 'polsat'));
});

test('GET /api/health reports status', async () => {
  const res = await supertest(app).get('/api/health');
  assert.equal(res.status, 200);
  assert.equal(res.body.status, 'ok');
  assert.equal(res.body.redis, false);
  assert.equal(typeof res.body.articlesCached, 'boolean');
});

test('GET /api/refresh requires secret when CRON_SECRET is set', async () => {
  process.env.CRON_SECRET = 'test-secret';
  const denied = await supertest(app).get('/api/refresh');
  assert.equal(denied.status, 401);
  const allowed = await supertest(app)
    .get('/api/refresh')
    .set('Authorization', 'Bearer test-secret');
  assert.equal(allowed.status, 200);
  assert.equal(allowed.body.ok, true);
  delete process.env.CRON_SECRET;
});
