'use strict';

process.env.NODE_ENV = 'test';
process.env.TRANSLATE_DISABLED = '1';

const { test, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert');
const { setupNetwork, teardownNetwork } = require('./helpers');
const store = require('../src/store');
const { diversify, enrichImages, getEdition, ogKey } = require('../src/refresh');

beforeEach(() => {
  store.clearMemory();
  setupNetwork(); // any unexpected network call throws
});

afterEach(() => teardownNetwork());

test('diversify caps per source, sorts newest-first, caps edition size', () => {
  const articles = [];
  for (let i = 0; i < 20; i++) {
    articles.push({ sourceId: 'a', pubDate: new Date(2026, 0, i + 1).toISOString() });
  }
  for (let i = 0; i < 5; i++) {
    articles.push({ sourceId: 'b', pubDate: new Date(2026, 5, i + 1).toISOString() });
  }
  const result = diversify(articles);
  assert.equal(result.filter(a => a.sourceId === 'a').length, 8); // per-source cap
  assert.equal(result.filter(a => a.sourceId === 'b').length, 5);
  assert.equal(result[0].sourceId, 'b'); // newest first
  assert.ok(result.length <= 60);
});

test('enrichImages applies cached og results without network', async () => {
  const a1 = { link: 'https://site.com/with-image', imageUrl: null };
  const a2 = { link: 'https://site.com/known-no-image', imageUrl: null };
  await store.set(ogKey(a1.link), 'https://cdn.site.com/photo.jpg');
  await store.set(ogKey(a2.link), 'none');

  await enrichImages([a1, a2], 0); // limit 0: cached results only, no scraping
  assert.equal(a1.imageUrl, 'https://cdn.site.com/photo.jpg');
  assert.equal(a2.imageUrl, null);
});

test('enrichImages leaves articles with existing images untouched', async () => {
  const a = { link: 'https://site.com/x', imageUrl: 'https://feed.com/original.jpg' };
  await enrichImages([a], 0);
  assert.equal(a.imageUrl, 'https://feed.com/original.jpg');
});

test('getEdition serves a fresh stored edition without any network call', async () => {
  const edition = {
    articles: [{ title: 'Cached', link: 'https://x/1', country: 'UK', category: 'world', sourceId: 'bbc' }],
    updatedAt: Date.now()
  };
  await store.set('articles:en', edition);
  const result = await getEdition('en'); // network is disabled — would throw if it tried
  assert.equal(result.articles[0].title, 'Cached');
});
