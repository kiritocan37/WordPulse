'use strict';

process.env.NODE_ENV = 'test';

const { test } = require('node:test');
const assert = require('node:assert');
const { extractOgImageFromHtml } = require('../src/scrape');

test('extracts og:image (property-first attribute order)', () => {
  const html = '<head><meta property="og:image" content="https://cdn.site.com/img.jpg"/></head>';
  assert.equal(extractOgImageFromHtml(html), 'https://cdn.site.com/img.jpg');
});

test('extracts og:image (content-first attribute order)', () => {
  const html = '<meta content="https://cdn.site.com/img2.jpg" property="og:image">';
  assert.equal(extractOgImageFromHtml(html), 'https://cdn.site.com/img2.jpg');
});

test('falls back to twitter:image', () => {
  const html = '<meta name="twitter:image" content="https://cdn.site.com/tw.jpg">';
  assert.equal(extractOgImageFromHtml(html), 'https://cdn.site.com/tw.jpg');
});

test('decodes &amp; in URLs', () => {
  const html = '<meta property="og:image" content="https://s.com/i.jpg?a=1&amp;b=2">';
  assert.equal(extractOgImageFromHtml(html), 'https://s.com/i.jpg?a=1&b=2');
});

test('rejects non-http values and empty input', () => {
  assert.equal(extractOgImageFromHtml('<meta property="og:image" content="data:image/png;base64,x">'), null);
  assert.equal(extractOgImageFromHtml(''), null);
  assert.equal(extractOgImageFromHtml('<head><title>no image</title></head>'), null);
});

test('resolves relative og:image against the article URL', () => {
  const html = '<meta property="og:image" content="/images/photo.jpg">';
  assert.equal(
    extractOgImageFromHtml(html, 'https://news.site.com/article/1'),
    'https://news.site.com/images/photo.jpg'
  );
});
