'use strict';

process.env.NODE_ENV = 'test';
process.env.TRANSLATE_DISABLED = '1';

const { test, beforeEach } = require('node:test');
const assert = require('node:assert');
const store = require('../src/store');
const { translateArticles, translateArticle, translationKey, apiLang } = require('../src/translate');

beforeEach(() => store.clearMemory());

test('apiLang maps ua -> uk and passes others through', () => {
  assert.equal(apiLang('ua'), 'uk');
  assert.equal(apiLang('en'), 'en');
  assert.equal(apiLang('ru'), 'ru');
});

test('articles already in target language pass through unchanged', async () => {
  const article = { title: 'T', description: 'D', originalLang: 'en', link: 'https://x/1' };
  const result = await translateArticle(article, 'en');
  assert.equal(result.title, 'T');
  assert.equal(result.description, 'D');
});

test('uk-language source passes through for ua target', async () => {
  const article = { title: 'Т', description: 'Д', originalLang: 'uk', link: 'https://x/2' };
  const result = await translateArticle(article, 'ua');
  assert.equal(result.title, 'Т');
});

test('cached translations are applied without any provider call', async () => {
  const article = { title: 'Bonjour', description: 'Le monde', originalLang: 'fr', link: 'https://x/3' };
  await store.set(translationKey(article, 'ru'), { title: 'Привет', description: 'Мир' });
  const [result] = await translateArticles([article], 'ru');
  assert.equal(result.title, 'Привет');
  assert.equal(result.description, 'Мир');
});

test('provider failure keeps original text instead of dropping articles', async () => {
  // TRANSLATE_DISABLED simulates all providers failing
  const article = { title: 'Bonjour', description: 'Le monde', originalLang: 'fr', link: 'https://x/4' };
  const [result] = await translateArticles([article], 'ru');
  assert.equal(result.title, 'Bonjour'); // graceful: original kept
});

test('translationKey is stable and language-scoped', () => {
  const a = { link: 'https://example.com/article' };
  assert.equal(translationKey(a, 'ru'), translationKey(a, 'ru'));
  assert.notEqual(translationKey(a, 'ru'), translationKey(a, 'uk'));
});
